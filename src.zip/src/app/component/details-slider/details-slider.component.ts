import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-slider',
  templateUrl: './details-slider.component.html',
  styleUrls: ['./details-slider.component.css']
})
export class DetailsSliderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
