export class Details {
    title: string;
    url: string;
}
