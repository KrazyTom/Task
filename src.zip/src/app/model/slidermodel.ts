export class SliderModel {
    id: string;
    title: string;
    landscapePosterId: string;
}
