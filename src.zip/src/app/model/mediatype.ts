import { Details } from './details';

export class MediaType {
    type: string;
    landscapePosterId: Details[];
}
